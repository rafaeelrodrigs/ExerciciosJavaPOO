package herancaAnimal;
/**
 *
 * @author RafaeelRodrigues
 */
public class PicaPau extends Animal {
    private String tamanho;

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }
    public PicaPau(String nome, int idade, String tamanho){
        super(nome, idade);
        this.tamanho=tamanho;
    }
    public String toString(){
        return"\n Dados do Pica-Pau:"+
                "\nNome: "+getNome()+
                "\nIdade: "+getIdade()+
                "\nTamanho: "+getTamanho();
    }
    
}
