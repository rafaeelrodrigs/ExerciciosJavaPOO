package herancaAnimal;
/**
 *
 * @author RafaeelRodrigues
 */
public class Gato extends Animal {
    private String cor;

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }
    public Gato(String nome, int idade, String cor){
        super(nome, idade);
        this.cor=cor;
    }
    public String toString(){
        return"\n Dados do Gato: "+
                "\nNome: "+getNome()+
                "\nIdade: "+getIdade()+
                "\nCor: "+getCor();
    }
    
}
