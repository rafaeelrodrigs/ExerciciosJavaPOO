package herancaAnimal;
/**
 *
 * @author RafaeelRodrigues
 */
public class TesteAnimal {

    public static void main(String[] args) {
       Cachorro ca = new Cachorro("Cripto", 14, "Vira Lata");
       Gato ga = new Gato("Gato de Botas", 7, "Amarelo");
       PicaPau pi = new PicaPau("Pipoca", 2, "pequeno");
       
        System.out.println(ca);
        System.out.println("================");
        System.out.println(ga);
        System.out.println("================");
        System.out.println(pi);
    }
}
